# Sodium v2.51
[![Documentation Status](https://readthedocs.org/projects/libsodium/badge/?version=latest)](https://libsodium.readthedocs.io/en/latest/?badge=latest)
![PyPI](https://img.shields.io/pypi/v/libsodium)

Sodium is a WSGI web framework(like django) that is built for creating API's.
# Instalation
Linux/MacOS:
```
pip3 install libsodium
```
Windows:
```
pip install libsodium
```

# Documentation
Read our Documentation at <a>https://libsodium.readthedocs.io/en/latest/</a>
